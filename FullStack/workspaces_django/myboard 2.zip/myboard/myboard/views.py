from django.shortcuts import render, redirect
from django.utils import timezone
from .models import MyBoard


def index(request):
    return render(request, 'index.html', {'list': MyBoard.objects.all().order_by('-id')})

def insert_form(request):
    return render(request, 'insert.html')

def insert_res(request):
    myname = request.POST['myname']
    mytitle = request.POST['mytitle']
    mycontent = request.POST['mycontent']

    result = MyBoard.objects.create(myname=myname, mytitle=mytitle, mycontent=mycontent, mydate=timezone.now())

    if result:
        return redirect('index')
    else:
        return redirect('insertform')


# 아이디 값 같이 보내자고 index에 설정했으니 id도 작성!
def detail(request, id):
    return render(request, 'detail.html', {'dto': MyBoard.objects.get(id=id)})


# 데베에서 내가 원하는 id의 데이터들을 가져올 것임.
def update_form(request, id):
    return render(request, 'update.html', {'dto': MyBoard.objects.get(id=id)})

# 여기서는 포스트 방식으로 보내진 데이터를 겟하는 것임
def update_res(request):
    id = request.POST['id']
    mytitle = request.POST['mytitle']
    mycontent = request.POST['mycontent']

    # 아이디에 맞는 데이터 가져오는데 이게 where의 역할
    myboard = MyBoard.objects.filter(id=id)
    result_title = myboard.update(mytitle=mytitle)
    result_content = myboard.update(mycontent=mycontent)

    # 여기 위에 print 찍어보고 밑에꺼 이유 찾아보기
    if result_title + result_content == 2:
        return redirect('/detail/' + id)
    else:
        return redirect('/updateform/'+ id)


def delete(request, id):
    result_delete = MyBoard.objects.filter(id=id).delete()
    print(result_delete)
    # 여기 0인덱스에는 어떤 값이 있음. 확인해보자
    if result_delete[0]:
        return redirect('index')
    else:
        return redirect('/detail/' + id)
