from django.shortcuts import render,redirect
from django.utils import timezone
from .models import MyBoard

# Create your views here.
def index(request):
    return render(request,'index.html', {'list':MyBoard.objects.all().order_by('-id')} )
    # return render(request,'./index.html',)

def insert(request):
    return render(request, 'insert.html')

def insertres(request):
    myname = request.POST['myname']
    mytitle = request.POST['mytitle']
    mycontent = request.POST['mycontent']

    result = MyBoard.objects.create(myname=myname,mytitle=mytitle,mycontent=mycontent,mydate=timezone.now())
    if result :
        return redirect('index')
    else : return redirect('insert')
    # if result

def detail(request,id):
    return render(request,'detail.html',{'dto':MyBoard.objects.get(id=id)})

def update(request,id):
    return render(request,'update.html',{'dto':MyBoard.objects.get(id=id)})

def updateres(request,id):
    # id = request.POST['id']
    myname = request.POST['myname']
    mytitle = request.POST['mytitle']
    mycontent = request.POST['mycontent']
    print(id)

    result = MyBoard.objects.create(myname=myname,mytitle=mytitle,mycontent=mycontent,mydate=timezone.now())
    if result :
        return redirect('detail')
    else : return redirect('update')
    # if result